/**
 * ESP32_01_I2C_Dual_LCD
 * Modul 06 - I2C & Sensor
 *
 * Contoh: ESP32 terhubung ke dua modul LCD I2C (misalnya 0x27 dan 0x3F)
 * menggunakan ESP-IDF I2C Master API.
 */

#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/i2c.h"
#include "esp_log.h"

static const char *TAG = "I2C_LCD";

/* ---- Pin & Konfigurasi I2C ---- */
#if CONFIG_IDF_TARGET_ESP32
#define I2C_SDA 21
#define I2C_SCL 22
#elif CONFIG_IDF_TARGET_ESP32S2 || CONFIG_IDF_TARGET_ESP32S3
#define I2C_SDA 8
#define I2C_SCL 9
#else
#define I2C_SDA 21
#define I2C_SCL 22
#endif

#define I2C_PORT I2C_NUM_0
#define I2C_FREQ_HZ 100000

#define LCD_ADDR_1 0x27
#define LCD_ADDR_2 0x3F

#define LCD_BACKLIGHT 0x08
#define LCD_ENABLE    0x04
#define LCD_RW        0x02
#define LCD_RS        0x01

static const uint8_t lcd_addresses[] = { LCD_ADDR_1, LCD_ADDR_2 };
static const char *lcd_labels[] = { "LCD 0x27", "LCD 0x3F" };

static const uint8_t lcd_row_offsets[] = { 0x00, 0x40, 0x14, 0x54 };

static esp_err_t i2c_master_init(void)
{
    i2c_config_t conf = {
        .mode = I2C_MODE_MASTER,
        .sda_io_num = I2C_SDA,
        .scl_io_num = I2C_SCL,
        .sda_pullup_en = GPIO_PULLUP_ENABLE,
        .scl_pullup_en = GPIO_PULLUP_ENABLE,
        .master.clk_speed = I2C_FREQ_HZ,
    };

    esp_err_t err = i2c_param_config(I2C_PORT, &conf);
    if (err != ESP_OK) {
        return err;
    }

    return i2c_driver_install(I2C_PORT, conf.mode, 0, 0, 0);
}

static esp_err_t i2c_probe_address(uint8_t addr)
{
    i2c_cmd_handle_t cmd = i2c_cmd_link_create();
    esp_err_t err = i2c_master_start(cmd);
    if (err != ESP_OK) {
        i2c_cmd_link_delete(cmd);
        return err;
    }

    err = i2c_master_write_byte(cmd, (addr << 1) | I2C_MASTER_WRITE, true);
    if (err != ESP_OK) {
        i2c_cmd_link_delete(cmd);
        return err;
    }

    err = i2c_master_stop(cmd);
    if (err == ESP_OK) {
        err = i2c_master_cmd_begin(I2C_PORT, cmd, pdMS_TO_TICKS(50));
    }

    i2c_cmd_link_delete(cmd);
    return err;
}

static esp_err_t i2c_write_byte(uint8_t addr, uint8_t data)
{
    i2c_cmd_handle_t cmd = i2c_cmd_link_create();
    esp_err_t err = i2c_master_start(cmd);
    if (err != ESP_OK) {
        i2c_cmd_link_delete(cmd);
        return err;
    }

    err = i2c_master_write_byte(cmd, (addr << 1) | I2C_MASTER_WRITE, true);
    if (err == ESP_OK) {
        err = i2c_master_write_byte(cmd, data, true);
    }
    if (err == ESP_OK) {
        err = i2c_master_stop(cmd);
    }
    if (err == ESP_OK) {
        err = i2c_master_cmd_begin(I2C_PORT, cmd, pdMS_TO_TICKS(100));
    }

    i2c_cmd_link_delete(cmd);
    return err;
}

static esp_err_t lcd_pulse_enable(uint8_t addr, uint8_t data)
{
    esp_err_t err = i2c_write_byte(addr, data | LCD_ENABLE);
    if (err != ESP_OK) {
        return err;
    }
    vTaskDelay(pdMS_TO_TICKS(1));
    return i2c_write_byte(addr, data & ~LCD_ENABLE);
}

static esp_err_t lcd_write4bits(uint8_t addr, uint8_t data)
{
    esp_err_t err = i2c_write_byte(addr, data | LCD_BACKLIGHT);
    if (err != ESP_OK) {
        return err;
    }
    return lcd_pulse_enable(addr, data | LCD_BACKLIGHT);
}

static esp_err_t lcd_send(uint8_t addr, uint8_t value, uint8_t mode)
{
    esp_err_t err = lcd_write4bits(addr, (value & 0xF0) | mode);
    if (err != ESP_OK) {
        return err;
    }
    return lcd_write4bits(addr, ((value << 4) & 0xF0) | mode);
}

static esp_err_t lcd_command(uint8_t addr, uint8_t value)
{
    return lcd_send(addr, value, 0);
}

static esp_err_t lcd_write_char(uint8_t addr, uint8_t value)
{
    return lcd_send(addr, value, LCD_RS);
}

static esp_err_t lcd_init_device(uint8_t addr)
{
    vTaskDelay(pdMS_TO_TICKS(50));

    esp_err_t err = lcd_write4bits(addr, 0x30);
    if (err != ESP_OK) return err;
    vTaskDelay(pdMS_TO_TICKS(5));

    err = lcd_write4bits(addr, 0x30);
    if (err != ESP_OK) return err;
    ets_delay_us(200);

    err = lcd_write4bits(addr, 0x30);
    if (err != ESP_OK) return err;
    err = lcd_write4bits(addr, 0x20);
    if (err != ESP_OK) return err;

    err = lcd_command(addr, 0x28); // 4-bit, 2 line, 5x8
    if (err != ESP_OK) return err;
    err = lcd_command(addr, 0x08); // display off
    if (err != ESP_OK) return err;
    err = lcd_command(addr, 0x01); // clear display
    if (err != ESP_OK) return err;
    vTaskDelay(pdMS_TO_TICKS(2));
    err = lcd_command(addr, 0x06); // entry mode set
    if (err != ESP_OK) return err;
    return lcd_command(addr, 0x0C); // display on, cursor off
}

static esp_err_t lcd_clear(uint8_t addr)
{
    esp_err_t err = lcd_command(addr, 0x01);
    if (err == ESP_OK) {
        vTaskDelay(pdMS_TO_TICKS(2));
    }
    return err;
}

static esp_err_t lcd_set_cursor(uint8_t addr, uint8_t col, uint8_t row)
{
    if (row > 1) {
        row = 1;
    }
    return lcd_command(addr, 0x80 | (col + lcd_row_offsets[row]));
}

static esp_err_t lcd_print_line(uint8_t addr, uint8_t row, const char *text)
{
    esp_err_t err = lcd_set_cursor(addr, 0, row);
    if (err != ESP_OK) {
        return err;
    }

    size_t len = strlen(text);
    if (len > 16) {
        len = 16;
    }

    for (size_t i = 0; i < len; i++) {
        err = lcd_write_char(addr, text[i]);
        if (err != ESP_OK) {
            return err;
        }
    }
    return ESP_OK;
}

static const char* get_device_name(uint8_t addr)
{
    switch (addr) {
        case 0x20: return "PCF8574 / MCP23017";
        case 0x21: return "PCF8574 (A0=1)";
        case 0x22: return "PCF8574 (A1=1)";
        case 0x23: return "PCF8574 / BH1750";
        case 0x27: return "PCF8574 (LCD I2C)";
        case 0x3C: return "SSD1306 OLED";
        case 0x3D: return "SSD1306 OLED (alt)";
        case 0x40: return "INA219 / HDC1080 / PCA9685";
        case 0x48: return "ADS1115 / PCF8591 / TMP102";
        case 0x49: return "ADS1115 (A0=1)";
        case 0x50: return "AT24C32 EEPROM";
        case 0x51: return "AT24C32 EEPROM (A0=1)";
        case 0x52: return "AT24C32 EEPROM (A1=1)";
        case 0x57: return "AT24C32 (DS3231 board)";
        case 0x5A: return "MLX90614";
        case 0x5B: return "CCS811";
        case 0x60: return "SI1145 / MCP4725";
        case 0x68: return "MPU6050 / DS3231 RTC";
        case 0x69: return "MPU6050 (AD0=1)";
        case 0x76: return "BMP280 / BME280";
        case 0x77: return "BMP280 / BME280 (alt)";
        default:   return "Tidak dikenal";
    }
}

static void i2c_scan(void)
{
    uint8_t found[128];
    int count = 0;

    printf("\n======================================\n");
    printf("       I2C BUS SCANNER\n");
    printf("======================================\n");
    printf("SDA=GPIO%d  SCL=GPIO%d  Freq=%dHz\n", I2C_SDA, I2C_SCL, I2C_FREQ_HZ);
    printf("--------------------------------------\n");
    printf("     0  1  2  3  4  5  6  7  8  9  A  B  C  D  E  F\n");

    for (int row = 0; row < 8; row++) {
        printf("%02X: ", row * 16);
        for (int col = 0; col < 16; col++) {
            uint8_t addr = (uint8_t)(row * 16 + col);
            if (addr < 0x01 || addr > 0x7F) {
                printf("   ");
                continue;
            }
            if (i2c_probe_address(addr) == ESP_OK) {
                printf("%02X ", addr);
                found[count++] = addr;
            } else {
                printf("-- ");
            }
        }
        printf("\n");
    }

    printf("--------------------------------------\n");
    printf("Ditemukan %d perangkat.\n\n", count);

    if (count > 0) {
        printf("Daftar perangkat:\n");
        printf("  Alamat  | Nama\n");
        printf("  --------|---------------------------\n");
        for (int i = 0; i < count; i++) {
            printf("  0x%02X    | %s\n", found[i], get_device_name(found[i]));
            printf("DEVICE_FOUND: addr=0x%02X name=%s\n", found[i], get_device_name(found[i]));
        }
    }
    printf("SCAN_COMPLETE: total=%d\n\n", count);
}

void app_main(void)
{
    ESP_LOGI(TAG, "Inisialisasi I2C Master...");
    ESP_ERROR_CHECK(i2c_master_init());

    ESP_LOGI(TAG, "Memindai bus I2C...");
    i2c_scan();

    for (size_t i = 0; i < sizeof(lcd_addresses) / sizeof(lcd_addresses[0]); i++) {
        uint8_t addr = lcd_addresses[i];
        if (i2c_probe_address(addr) == ESP_OK) {
            ESP_LOGI(TAG, "Inisialisasi %s (0x%02X)", lcd_labels[i], addr);
            if (lcd_init_device(addr) == ESP_OK) {
                lcd_clear(addr);
                lcd_print_line(addr, 0, lcd_labels[i]);
                lcd_print_line(addr, 1, "ESP32 dual LCD");
            } else {
                ESP_LOGE(TAG, "Gagal inisialisasi LCD di alamat 0x%02X", addr);
            }
        } else {
            ESP_LOGW(TAG, "Tidak ditemukan LCD di alamat 0x%02X", addr);
        }
    }

    while (1) {
        ESP_LOGI(TAG, "I2C dual-LCD aktif. Scan ulang dalam 10 detik...");
        vTaskDelay(pdMS_TO_TICKS(10000));
    }
}
