#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

#define BUTTON_PIN PB0
#define LED_PIN PC13

volatile bool isTouched = false;
float phase = 0;
int touchAnimCounter = 0;

// Fungsi Interrupt saat tombol ditekan
void buttonISR() {
  isTouched = true;
  touchAnimCounter = 20; // Durasi animasi kaget (20 frame)
}

void setup() {
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  Wire.setClock(400000);
  
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  pinMode(LED_PIN, OUTPUT);
  
  // Pasang interrupt di PB0
  attachInterrupt(digitalPinToInterrupt(BUTTON_PIN), buttonISR, FALLING);
}

void loop() {
  display.clearDisplay();

  float squash = sin(phase) * 5; 
  float yOffset = sin(phase) * 8;
  
  // LOGIKA REAKSI KAGET
  if (touchAnimCounter > 0) {
    // Kalau lagi kaget: Mochi jadi gepeng banget dan mata jadi besar
    squash = 15;   // Jadi lebih lebar
    yOffset = 15;  // Jadi lebih turun (mendekat ke lantai)
    touchAnimCounter--;
    digitalWrite(LED_PIN, LOW); // Nyalakan LED pas kaget
  } else {
    isTouched = false;
    digitalWrite(LED_PIN, HIGH); // Matikan LED
  }

  int mochiW = 40 + squash;
  int mochiH = 30 - squash;
  int x = (SCREEN_WIDTH - mochiW) / 2;
  int y = 35 + yOffset;

  // Gambar Badan Mochi
  display.fillRoundRect(x, y, mochiW, mochiH, 15, WHITE);

  // Gambar Mata
  if (touchAnimCounter > 0) {
    // Mata kaget (O)
    display.drawCircle(x + (mochiW * 0.3), y + 10, 4, BLACK);
    display.drawCircle(x + (mochiW * 0.7), y + 10, 4, BLACK);
    display.setCursor(x + (mochiW * 0.4), y + 18);
    display.setTextColor(BLACK);
    display.print("o"); // Mulut kaget kecil
  } else {
    // Mata normal (.)
    display.fillCircle(x + (mochiW * 0.3), y + 10, 2, BLACK);
    display.fillCircle(x + (mochiW * 0.7), y + 10, 2, BLACK);
  }

  display.display();

  phase += 0.15;
  delay(20);
}