#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

#define BUTTON_PIN PB0
#define LED_PIN PC13

volatile uint32_t count = 0;
volatile bool flag = false;

void buttonISR() {
  count++;
  flag = true;
}

void setup() {
  Serial.begin(115200);
  delay(2000);
  Serial.println("Program 01: EXTI Interrupt - STM32\n");

  pinMode(BUTTON_PIN, INPUT_PULLUP);
  pinMode(LED_PIN, OUTPUT);

  attachInterrupt(digitalPinToInterrupt(BUTTON_PIN), buttonISR, FALLING);
  Serial.println("EXTI configured on PB0 (FALLING edge)");

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println(F("SSD1306 allocation failed"));
    for (;;);
  }
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(0, 0);
  display.println("Waiting for interrupt...");
  display.display();
}

void loop() {
  if (flag) {
    flag = false;
    digitalWrite(LED_PIN, !digitalRead(LED_PIN));
    Serial.printf("Interrupt #%lu\n", count);

    display.clearDisplay();
    display.setTextSize(2);
    display.setTextColor(WHITE);
    display.setCursor(0, 0);
    display.printf("Intr: %lu", count);
    display.display();
  }
}
